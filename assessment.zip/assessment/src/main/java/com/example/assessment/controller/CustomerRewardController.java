package com.example.assessment.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.assessment.dto.CustomerRewards;
import com.example.assessment.dto.TransactionRewards;
import com.example.assessment.model.Customer;
import com.example.assessment.model.Transaction;
import com.example.assessment.service.CustomerRepo;
import com.example.assessment.service.RewardService;
import com.example.assessment.service.TransactionRepo;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/rewards")
public class CustomerRewardController {
  private static final String CONTENT_TYPE = "application/json";
  private final CustomerRepo customerRepo;

  private final TransactionRepo transactionRepo;

  private final RewardService rewardService;

  public CustomerRewardController(CustomerRepo customerRepo, TransactionRepo transactionRepo,
                                  RewardService rewardService) {
    this.customerRepo = customerRepo;
    this.transactionRepo = transactionRepo;
    this.rewardService = rewardService;
  }

  @GetMapping(value="/customers/{customerId}",produces = {CONTENT_TYPE})
  ResponseEntity<Integer> getRewardsPointsByCustomerId(@PathVariable Long customerId,
                                               @RequestParam(defaultValue = "1")int month) {


    Optional<Customer> oCustomer= customerRepo.findById(customerId);
    if(oCustomer.isEmpty()){
    return ResponseEntity.notFound().build();
  }

    Customer customer= oCustomer.get();
    LocalDate startDate= LocalDate.now().minusMonths(month).withDayOfMonth(1);
    LocalDate endDate= LocalDate.now().minusMonths(month-1).withDayOfMonth(1).minusDays(1);

    List<Transaction> listOfTransactions= transactionRepo.findByCustomerUserIdAndDateBetween(customerId,startDate,endDate);

    int totalRewards =0;

    List<TransactionRewards> transactionRewardsList = new ArrayList<>();

    for(Transaction transaction: listOfTransactions){

    int transactionRewards= rewardService.calculateRewardPoints(transaction.getAmount());
    totalRewards += transactionRewards;
    transactionRewardsList.add(new TransactionRewards(transaction.getAmount(),totalRewards));
    }

    CustomerRewards customerRewards= new CustomerRewards(customer.getCustomerName(),totalRewards,transactionRewardsList);
    return ResponseEntity.ok(customerRewards.getTotalRewards());
  }
}
