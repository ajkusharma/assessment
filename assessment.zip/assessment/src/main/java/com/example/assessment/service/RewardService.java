package com.example.assessment.service;

import java.math.BigDecimal;
import org.springframework.stereotype.Service;

@Service
public class RewardService {
public int calculateRewardPoints(BigDecimal amount){

  int rewardPoints=0;
  if(amount.compareTo(BigDecimal.valueOf(100))>0){
    rewardPoints+=2*(amount.intValue()-100);
  }
  if(amount.compareTo(BigDecimal.valueOf(50))>0){
    rewardPoints+=amount.intValue()-50;
  }
  return rewardPoints;
}

}
