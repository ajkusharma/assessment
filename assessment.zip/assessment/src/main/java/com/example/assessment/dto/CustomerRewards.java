package com.example.assessment.dto;

import java.util.List;

public class CustomerRewards {

  private String customerName;
  private int totalRewards;

  public String getCustomerName() {
    return customerName;
  }

  public void setCustomerName(String customerName) {
    this.customerName = customerName;
  }

  public int getTotalRewards() {
    return totalRewards;
  }

  public void setTotalRewards(int totalRewards) {
    this.totalRewards = totalRewards;
  }

  public List<TransactionRewards> getTransactionRewardsList() {
    return transactionRewardsList;
  }

  public void setTransactionRewardsList(List<TransactionRewards> transactionRewardsList) {
    this.transactionRewardsList = transactionRewardsList;
  }

  private List<TransactionRewards> transactionRewardsList;


  public CustomerRewards(String customerName, int totalRewards, List<TransactionRewards> transactionRewardsList) {
    this.customerName = customerName;
    this.totalRewards = totalRewards;
    this.transactionRewardsList = transactionRewardsList;
  }


}
