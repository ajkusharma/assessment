package com.example.assessment.service;

import java.time.LocalDate;
import java.util.List;
import com.example.assessment.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepo extends JpaRepository<Transaction,Long> {
  // List<Transaction> findByCustomerId(Long userId);
  List<Transaction> findByCustomerUserIdAndDateBetween(Long userId, LocalDate startDt, LocalDate endDt);
}
