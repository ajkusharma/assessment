package com.example.assessment.dto;

import java.math.BigDecimal;

public class TransactionRewards {

  private BigDecimal transactionAmount;

  public BigDecimal getTransactionAmount() {
    return transactionAmount;
  }

  public void setTransactionAmount(BigDecimal transactionAmount) {
    this.transactionAmount = transactionAmount;
  }

  public int getRewardPoint() {
    return rewardPoint;
  }

  public void setRewardPoint(int rewardPoint) {
    this.rewardPoint = rewardPoint;
  }

  private int rewardPoint;

  public TransactionRewards(BigDecimal transactionAmount, int rewardPoint) {
    this.transactionAmount = transactionAmount;
    this.rewardPoint = rewardPoint;
  }



}
