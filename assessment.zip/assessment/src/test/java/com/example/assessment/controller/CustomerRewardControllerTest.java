package com.example.assessment.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import static net.bytebuddy.matcher.ElementMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import com.example.assessment.controller.CustomerRewardController;
import com.example.assessment.model.Customer;
import com.example.assessment.model.Transaction;
import com.example.assessment.service.CustomerRepo;
import com.example.assessment.service.RewardService;
import com.example.assessment.service.TransactionRepo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.client.match.MockRestRequestMatchers;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@RunWith(MockitoJUnitRunner.class)
public class CustomerRewardControllerTest{

  @Mock
  private CustomerRepo customerRepo;

  @Mock
  private TransactionRepo transactionRepo;

  @Mock
  private RewardService rewardService;

  @InjectMocks
  private CustomerRewardController customerRewardController;

  private MockMvc mockMvc;

  @Before
  public void setUp(){
    mockMvc= MockMvcBuilders.standaloneSetup(customerRewardController).build();
  }

  @Test
  public void testGetCustomerRewards()throws Exception{

    Customer customer= new Customer();
    customer.setUserId(1L);
    customer.setCustomerName("ajay");

    Transaction transaction = new Transaction();
    transaction.setUserId(1L);
    transaction.setDate(LocalDate.now().minusMonths(3));
    transaction.setAmount(BigDecimal.valueOf(120));
    transaction.setCustomer(customer);

    Transaction transaction1 = new Transaction();
    transaction1.setUserId(2L);
    transaction1.setDate(LocalDate.now().minusMonths(2));
    transaction1.setAmount(BigDecimal.valueOf(80));
    transaction1.setCustomer(customer);

    List<Transaction> transactionList = Arrays.asList(transaction1,transaction);
    when(customerRepo.findById(1L)).thenReturn(Optional.of(customer));
    // when(transactionRepo.findByCustomerUserIdAndDateBetween(eq(1L),any(LocalDate.class),any(LocalDate.class)));

    //doReturn(90).when(rewardService.calculateRewardPoints(BigDecimal.valueOf(120)));
    //doReturn(30).when(rewardService.calculateRewardPoints(BigDecimal.valueOf(80)));

    mockMvc.perform(get("/api/rewards/customers/{customerId}",1)
        .param("month","2"))
        .andExpect(status().isOk());
       /* .andExpect((ResultMatcher) jsonPath("$.customerName",is("Ajay Sharma")))
        .andExpect((ResultMatcher) jsonPath("$.totalRewards",is(120)))
        .andExpect((ResultMatcher) jsonPath("$.transactionRewardsList",hasSize(2)))
        .andExpect((ResultMatcher) jsonPath("$.transactionRewardsList[0].transactionAmount",is(120)))
        .andExpect((ResultMatcher) jsonPath("$.transactionRewardsList[0].transactionAmount",is(90)))
        .andExpect((ResultMatcher) jsonPath("$.transactionRewardsList[0].transactionAmount",is(80)))
        .andExpect((ResultMatcher) jsonPath("$.transactionRewardsList[0].transactionAmount",is(30)));*/

  //  verify(customerRepo.findById(1L));
  //  verify(transactionRepo.findByCustomerUserIdAndDateBetween(eq(1L),any(LocalDate.class),any(LocalDate.class)));
    //verify(rewardService.calculateRewardPoints(BigDecimal.valueOf(120)));
   // verify(rewardService.calculateRewardPoints(BigDecimal.valueOf(80)));
  }
}